//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An auxiliary source file which is part of the book-level auxiliary sources.
//  Provides the implementation of the "always-on" live view.
//

// If you're reading this, I'm sorry, I wish I had more time to clean up the code. Anyway thanks for your time, have a lovely day 😀

import Foundation
import UIKit
import PlaygroundSupport
import ARKit
import SceneKit

@objc(Book_Sources_LiveViewController)
public class LiveViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer, ARSCNViewDelegate {
    
    // MARK: Setup
    
    public var sceneView: ARSCNView = ARSCNView()
    
    public var dummyArray = [SCNNode]()
    
    public var animations = [String: CAAnimation]()
    
    public var dummy:Bool = true
    public var matWasPlaced: Bool = false
    public var dummyWasPlaced:Bool = false
    public var dummyPosition: SCNVector3 = SCNVector3()
    public var handsPosition: SCNVector3 = SCNVector3()
    
    func removeNode (name: String){
        sceneView.scene.rootNode.enumerateChildNodes { (node, _) in
            if node.name == name {
                node.removeFromParentNode()
            }
        }
    }
    
    // MARK: Create label
    
    public var viewLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 30.0, weight: .bold)
        label.textColor = .white
        label.textAlignment = .center
        label.numberOfLines = 3
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    private var blurView: UIVisualEffectView = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view = sceneView
        
        sceneView.clipsToBounds = true
        sceneView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            sceneView.leadingAnchor.constraint(equalTo: self.liveViewSafeAreaGuide.leadingAnchor),
            sceneView.trailingAnchor.constraint(equalTo: self.liveViewSafeAreaGuide.trailingAnchor),
            sceneView.topAnchor.constraint(equalTo: self.liveViewSafeAreaGuide.topAnchor),
            sceneView.bottomAnchor.constraint(equalTo: self.liveViewSafeAreaGuide.bottomAnchor)
            ])
        
        sceneView.delegate = self
        
        let scene = SCNScene()
        sceneView.scene = scene
        
        // MARK: Place label
        
        self.view.addSubview(blurView)
        self.view.addSubview(viewLabel)
        
        viewLabel.text = "Look around you to find the mat with the red cross ❌"
        
        let labelTopConstraint = NSLayoutConstraint(item: self.viewLabel, attribute: .top, relatedBy: .equal, toItem: self.view, attribute: .top, multiplier: 1, constant: 64)
        let labelLeadingConstraint = NSLayoutConstraint(item: self.viewLabel, attribute: .left, relatedBy: .equal, toItem: self.view, attribute: .left, multiplier: 1, constant: 0)
        let labelTrailingConstraint = NSLayoutConstraint(item: self.viewLabel, attribute: .right, relatedBy: .equal, toItem: self.view, attribute: .right, multiplier: 1, constant: 0)
        let labelHeight = NSLayoutConstraint (item: self.viewLabel, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 0, constant: 100)
        self.view.addConstraints([labelTopConstraint, labelLeadingConstraint, labelTrailingConstraint, labelHeight])
        
        let blurTopConstraints = NSLayoutConstraint(item: blurView, attribute: .top, relatedBy: .equal, toItem: self.viewLabel, attribute: .top, multiplier: 1, constant: 0)
        let blurLeadingConstraint = NSLayoutConstraint(item: blurView, attribute: .left, relatedBy: .equal, toItem: self.viewLabel, attribute: .left, multiplier: 1, constant: 0)
        let blurTrailingConstraint = NSLayoutConstraint(item: blurView, attribute: .right, relatedBy: .equal, toItem: self.viewLabel, attribute: .right, multiplier: 1, constant: 0)
        let blurHeight = NSLayoutConstraint(item: blurView, attribute: .height, relatedBy: .equal, toItem: self.viewLabel, attribute: .height, multiplier: 1, constant: 0)
        self.view.addConstraints([blurTopConstraints, blurLeadingConstraint, blurTrailingConstraint, blurHeight])
        viewLabel.alpha = 1.0
        blurView.alpha = 1.0
        
        // TODO: Implement reset button
        /*
        let resetButton = UIButton(frame: CGRect(x: 100, y: 100, width: 100, height: 50))
        resetButton.backgroundColor = .clear
        resetButton.setTitle("Restart", for: .normal)
        resetButton.addTarget(self, action: <#T##Selector#>, for: .touchUpInside)
        self.view.addSubview(resetButton)
        */
        
        sceneView.autoenablesDefaultLighting = true
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let configuration = ARWorldTrackingConfiguration()
        
        configuration.planeDetection = .horizontal
        
        sceneView.session.run(configuration)
        
        blurView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(blurView)
        view.addSubview(viewLabel)
        
    }
    
    //  MARK: Create and place the mat
    
    func createFloor(planeAnchor: ARPlaneAnchor , node: SCNNode) -> SCNNode {
        
        let width = CGFloat( 0.3)
        let height = CGFloat( 0.3)
        let plane = SCNPlane(width: width, height: height)
        
        plane.materials.first?.diffuse.contents = UIImage(named: "grid.png")
        
        let planeNode = SCNNode(geometry: plane)
        
        planeNode.position = SCNVector3(x: planeAnchor.center.x, y: 0, z: planeAnchor.center.z)
        planeNode.eulerAngles.x = -.pi / 2
        
        planeNode.name = "floor"
        
        return planeNode
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        if anchor is ARPlaneAnchor, !dummyWasPlaced {
            
            removeNode(name: "floor")
            guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
            
            let planeNode = createFloor(planeAnchor: planeAnchor ,node: node)
            node.addChildNode(planeNode)
            
            viewLabel.text = "The surface was detected! Now touch where you want to add the CPR dummy"
            
        } else {
            return
        }
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        if anchor is ARPlaneAnchor, !dummyWasPlaced {
            
            removeNode(name: "floor")
            
            guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
            
            let planeNode = createFloor(planeAnchor: planeAnchor ,node: node)
            node.addChildNode(planeNode)
            
            viewLabel.text = "The surface was detected! Now touch where you want to add the CPR dummy"
            
        } else {
            return
        }
    }
    
    // MARK: Animation functions
    
    func loadAnimation(withKey: String, sceneName:String, animationIdentifier:String) {
        let sceneURL = Bundle.main.url(forResource: sceneName, withExtension: "dae")
        let sceneSource = SCNSceneSource(url: sceneURL!, options: nil)
        
        if let animationObject = sceneSource?.entryWithIdentifier(animationIdentifier, withClass: CAAnimation.self) {
            // To make transition between animations smooth
            animationObject.fadeInDuration = CGFloat(1)
            animationObject.fadeOutDuration = CGFloat(0.5)
            
            // Stores the animation for later use
            animations[withKey] = animationObject
        }
    }
    
    func playAnimation(key: String) {
        // Adds animation to start playing right away
        sceneView.scene.rootNode.addAnimation(animations[key]!, forKey: key)
    }
    
    func stopAnimation(key: String) {
        // Stop animation with smooth transition
        sceneView.scene.rootNode.removeAnimation(forKey: key, blendOutDuration: CGFloat(0.5))
    }
    
    // MARK: Place the dummy
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first, !dummyWasPlaced {
            let touchLocation  = touch.location(in: sceneView)
            
            let results = sceneView.hitTest(touchLocation, types: .existingPlaneUsingExtent)
            
            if let hitResult = results.first {
                
                // Load the dummy in idle mode
                let dummy = SCNScene(named: "dummy.dae")!
                
                // Parent node for all animations
                let node = SCNNode()
                
                // Add all the child nodes to parent node
                for child in dummy.rootNode.childNodes {
                    node.addChildNode(child)
                    
                }
                
                node.position = SCNVector3(hitResult.worldTransform.columns.3.x, hitResult.worldTransform.columns.3.y, hitResult.worldTransform.columns.3.z)
                self.dummyPosition = SCNVector3(hitResult.worldTransform.columns.3.x, hitResult.worldTransform.columns.3.y, hitResult.worldTransform.columns.3.z + 0.14)
                node.scale = SCNVector3(1, 1, 1)
                
                dummyWasPlaced = true
                
                // Add the node to the scene
                sceneView.scene.rootNode.addChildNode(node)
                
                // Update label
                viewLabel.text = "Nice, you can write the method and run your code now"
                
                // Load animations
                loadAnimation(withKey: "push", sceneName: "push", animationIdentifier: "push-1")
                loadAnimation(withKey: "breath", sceneName: "breath", animationIdentifier: "breath-1")
                loadAnimation(withKey: "tilt", sceneName: "tilt", animationIdentifier: "tilt-1")
                
                
            }
            
        }
    }
    
    // MARK: Message handler
    
    public func receive(_ message: PlaygroundValue) {
        
        guard case .data(let messageData) = message else { return }
        do { if let incomingObject = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(messageData) as? String {
            
            if incomingObject == "animatepush" && dummyWasPlaced{
                if(dummy) {
                    playAnimation(key: "push")
                    let hands = SCNScene(named: "hands.dae")!
                    let node = SCNNode()
                    for child in hands.rootNode.childNodes {
                        node.addChildNode(child)
                    }
                    node.position = self.dummyPosition
                    sceneView.scene.rootNode.addChildNode(node)
                } else {
                    stopAnimation(key: "push")
                }
                
                dummy = !dummy
                viewLabel.alpha = 0.0
                blurView.alpha = 0.0
                return
            } else if incomingObject == "animatebreath" && dummyWasPlaced {
                if(dummy) {
                    playAnimation(key: "breath")
                    let head = SCNScene(named: "head.dae")!
                    let node = SCNNode()
                    for child in head.rootNode.childNodes {
                        node.addChildNode(child)
                    }
                    node.position = self.dummyPosition
                    sceneView.scene.rootNode.addChildNode(node)
                } else {
                    stopAnimation(key: "breath")
                }
                viewLabel.alpha = 0.0
                blurView.alpha = 0.0
                dummy = !dummy
                return
            } else if incomingObject == "animatetilt" && dummyWasPlaced {
                if(dummy) {
                    playAnimation(key: "tilt")
                    let hand = SCNScene(named: "hand.dae")!
                    let node = SCNNode()
                    for child in hand.rootNode.childNodes {
                        node.addChildNode(child)
                    }
                    node.position = self.dummyPosition
                    sceneView.scene.rootNode.addChildNode(node)
                } else {
                    stopAnimation(key: "tilt")
                }
                viewLabel.alpha = 0.0
                blurView.alpha = 0.0
                dummy = !dummy
                return
            } else if incomingObject == "wronganswer" && dummyWasPlaced {
                viewLabel.text = "That's not correct, check the parameters and try again"
                return
            } else if incomingObject == "wrongfunction" && dummyWasPlaced {
                viewLabel.text = "You can't start CPR yet! Try with another function"
                return
            } else if incomingObject == "wrongfunction2" && dummyWasPlaced {
                viewLabel.text = "You can't finish CPR yet! Try with another function"
                return
            }
            
            }
        } catch let error { fatalError("\(error) Unable to receive the message from the Playground page") }
        
    }
    
}

