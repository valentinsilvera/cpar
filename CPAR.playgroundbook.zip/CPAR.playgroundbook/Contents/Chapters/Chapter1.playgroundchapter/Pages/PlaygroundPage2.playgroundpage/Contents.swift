//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
/*:
 
 ## Push hard and fast
 
 Once you checked that the victim is not breathing it's time to start administering the compresses. You need to push with a **pace** of **100 to 160 [bpm](glossary://BPM)**, with enough force to go between a **depth of 2 to 2.4 inches**.
 
 ###### Now it's your turn:
 
 * Place the CPR dummy.
 * Input the right [arguments](glossary://Arguments) to start the CPR pushes.
 
 */
//#-hidden-code
import PlaygroundSupport
import Foundation
import AVFoundation

let page = PlaygroundPage.current

func performPushes(pace: Int, depth: Double) {
    
    var pace = pace
    var depth = depth
    
    if pace >= 100 && pace <= 160 && depth >= 2.0 && depth <= 2.4  {
        do {
            sendValue(.data(try NSKeyedArchiver.archivedData(withRootObject: "animatepush", requiringSecureCoding: true)))
            
        }
        catch {
            
        }
        PlaygroundPage.current.assessmentStatus = .pass(message: "You're getting the hang of it. It's time to learn about rescue breaths🌬 in the [**Next Page**](@next)!")
    } else {
        do {
            sendValue(.data(try NSKeyedArchiver.archivedData(withRootObject: "wronganswer", requiringSecureCoding: true)))
        }
        catch {
            
        }
    }
}


//#-code-completion(everything, hide)

//#-end-hidden-code

performPushes(pace: /*#-editable-code*/<#T##pace##Int#>/*#-end-editable-code*/, depth: /*#-editable-code*/<#T##depth##Double#>/*#-end-editable-code*/)

//#-hidden-code

//#-end-hidden-code
