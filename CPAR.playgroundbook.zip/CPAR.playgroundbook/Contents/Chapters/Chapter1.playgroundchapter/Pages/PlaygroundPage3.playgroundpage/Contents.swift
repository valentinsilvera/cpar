//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
/*:
 
 ## Blow
 
 If you trained in CPR, it's time to try rescue breathing. Every 30 pushes you should perform **2 rescue breaths**.
 For this maneuver, the head should be tilted back, pinch the victim's nose and blow in the mouth. You should see the chest rising with every blow.
 
 ###### Now it's your turn:

 * Place the CPR dummy following the instructions on the right.
 * Input the right [method](glossary://Method) to start the rescue breaths.
 
 */
//#-hidden-code
import PlaygroundSupport
import Foundation
import AVFoundation

let page = PlaygroundPage.current

func startRescueBreaths() {
    do {
        sendValue(.data(try NSKeyedArchiver.archivedData(withRootObject: "animatebreath", requiringSecureCoding: true)))
    }
    catch {
        
    }
    PlaygroundPage.current.assessmentStatus = .pass(message: "You did it! You learned how to help someone who's having a cardiac arrest. [**Next Page**](@next)! has a short thank you note 😊")
}

func stopCPR() {
    do {
        sendValue(.data(try NSKeyedArchiver.archivedData(withRootObject: "wrongfunction2", requiringSecureCoding: true)))
    }
    catch {
        
    }
    
}



//#-code-completion(everything, hide)
//#-code-completion(identifier, show, startRescueBreaths(), stopCPR())
//#-end-hidden-code
//#-editable-code

//#-end-editable-code
//#-hidden-code



//#-end-hidden-code
