//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code

/*:
 * Callout(Important):
 This Playground is not a replacement for [CPR](glossary://CPR) training, but to show you the ropes and spark your interest to take the course. Now let's get started!
 */
/*:

 ‌‌
 
 ## First steps
 
 When you find an unconscious person check if the subject is breathing. Immediately call emergency services or ask someone else to do it for you, and to find an [AED](glossary://AED).
 
 CPR alone is unlikely to restart the heart. Its primary purpose is to restore the flow of oxygenated blood to the brain and heart. Therefore we need to open the airways of the victim by **tilting their head back**.
 
 ###### Now it's your turn:
 
 * Place the CPR dummy
 * Call the right [method](glossary://Method) to help the victim.
 
 */

//#-hidden-code
import PlaygroundSupport
import Foundation
import AVFoundation

let page = PlaygroundPage.current

func tiltHead() {
    do {
        sendValue(.data(try NSKeyedArchiver.archivedData(withRootObject: "animatetilt", requiringSecureCoding: true)))
    }
    catch {
       
    }
    PlaygroundPage.current.assessmentStatus = .pass(message: "Well done. Now it's time to learn about CPR pushes⚡️. You can go to the [**Next Page**](@next)!")
}

func startCPR() {
    do {
        sendValue(.data(try NSKeyedArchiver.archivedData(withRootObject: "wrongfunction", requiringSecureCoding: true)))
    }
    catch {
        
    }
    
}


//#-code-completion(everything, hide)
//#-code-completion(identifier, show, tiltHead(), startCPR())
//#-end-hidden-code
//#-editable-code

//#-end-editable-code
//#-hidden-code



//#-end-hidden-code
