//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
/*:
 
 ## Thank you

 Thank you for taking the time to go through this Playground Book. It was made with ❤️ by a medical student from Uruguay, now attending the Apple Developer Academy in Italy. I hope you enjoyed playing with it as much as I enjoyed making it.
 
 
 

 
 
 
 */

/*:
 - Note:
 "My favorite things in life don’t cost any money. It’s really clear that the most precious resource we all have is time."
 \
 Steve Jobs

 
 */


